#!/usr/bin/env node

import readline from "node:readline";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";
import chalk from "chalk";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, ".env") });

// Storage directories
const DATA_DIR = path.join(os.homedir(), ".grey");
const SESSIONS_DIR = path.join(DATA_DIR, "sessions");
const GALLERY_DIR = path.join(DATA_DIR, "gallery");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const GALLERY_INDEX = path.join(GALLERY_DIR, "index.json");
const VAULT_FILE = path.join(DATA_DIR, "vault.bin");

const VAULT_ARCHIVE_SECRET = "ShadowCreation";

const dirList = [DATA_DIR, SESSIONS_DIR, GALLERY_DIR];
for (let i = 0; i < dirList.length; i++) {
  if (!fs.existsSync(dirList[i])) {
    fs.mkdirSync(dirList[i], { recursive: true });
  }
}

// 30+ Direct Providers
const DIRECT_PROVIDERS = {
  gemini: { name: "Google Gemini Direct", url: "https://generativelanguage.googleapis.com/v1beta", type: "gemini", defaultModel: "gemini-2.5-flash" },
  openai: { name: "OpenAI Direct", url: "https://api.openai.com/v1", type: "openai", defaultModel: "gpt-4o-mini" },
  anthropic: { name: "Anthropic Direct", url: "https://api.anthropic.com/v1", type: "anthropic", defaultModel: "claude-3-5-sonnet-latest" },
  deepseek: { name: "DeepSeek Official", url: "https://api.deepseek.com/v1", type: "openai", defaultModel: "deepseek-chat" },
  groq: { name: "Groq LPU Cloud", url: "https://api.groq.com/openai/v1", type: "openai", defaultModel: "llama-3.3-70b-versatile" },
  mistral: { name: "Mistral AI", url: "https://api.mistral.ai/v1", type: "openai", defaultModel: "mistral-large-latest" },
  xai: { name: "xAI (Grok)", url: "https://api.x.ai/v1", type: "openai", defaultModel: "grok-2-latest" },
  perplexity: { name: "Perplexity AI", url: "https://api.perplexity.ai", type: "openai", defaultModel: "sonar" },
  cerebras: { name: "Cerebras Inference", url: "https://api.cerebras.ai/v1", type: "openai", defaultModel: "llama3.3-70b" },
  sambanova: { name: "SambaNova Cloud", url: "https://api.sambanova.ai/v1", type: "openai", defaultModel: "Meta-Llama-3.3-70B-Instruct" },
  cohere: { name: "Cohere API", url: "https://api.cohere.ai/v1", type: "cohere", defaultModel: "command-r-plus-08-2024" },
  meta: { name: "Meta Llama API", url: "https://api.llama-api.com", type: "openai", defaultModel: "llama3.3-70b" },
  qwen: { name: "Alibaba DashScope (Qwen)", url: "https://dashscope.aliyuncs.com/compatible-mode/v1", type: "openai", defaultModel: "qwen-plus" },
  moonshot: { name: "Moonshot AI (Kimi)", url: "https://api.moonshot.cn/v1", type: "openai", defaultModel: "moonshot-v1-8k" },
  zhipu: { name: "Zhipu AI (GLM-4)", url: "https://open.bigmodel.cn/api/paas/v4", type: "openai", defaultModel: "glm-4" },
  minimax: { name: "MiniMax", url: "https://api.minimax.chat/v1", type: "openai", defaultModel: "abab6.5-chat" },
  yi: { name: "01.AI (Yi)", url: "https://api.01.ai/v1", type: "openai", defaultModel: "yi-lightning" },
  stepfun: { name: "StepFun", url: "https://api.stepfun.com/v1", type: "openai", defaultModel: "step-1-8k" },
  doubao: { name: "ByteDance Doubao", url: "https://ark.cn-beijing.volces.com/api/v3", type: "openai", defaultModel: "doubao-pro-4k" },
  ai21: { name: "AI21 Labs", url: "https://api.ai21.com/studio/v1", type: "openai", defaultModel: "jamba-1.5-mini" },
  upstage: { name: "Upstage Solar", url: "https://api.upstage.ai/v1/solar", type: "openai", defaultModel: "solar-1-mini-chat" },
  replicate: { name: "Replicate", url: "https://api.replicate.com/v1", type: "openai", defaultModel: "meta/meta-llama-3-70b-instruct" },
  lepton: { name: "Lepton AI", url: "https://api.lepton.ai/api/v1", type: "openai", defaultModel: "llama3-1-70b" },
  deepinfra: { name: "DeepInfra", url: "https://api.deepinfra.com/v1/openai", type: "openai", defaultModel: "meta-llama/Meta-Llama-3.1-70B-Instruct" },
  anyscale: { name: "Anyscale Endpoints", url: "https://api.endpoints.anyscale.com/v1", type: "openai", defaultModel: "meta-llama/Meta-Llama-3.1-70B-Instruct" },
  cloudflare: { name: "Cloudflare Workers AI", url: "https://api.cloudflare.com/client/v4/accounts", type: "openai", defaultModel: "@cf/meta/llama-3-8b-instruct" },
  azure_openai: { name: "Azure OpenAI Models", url: "https://models.inference.ai.azure.com", type: "openai", defaultModel: "gpt-4o" },
  vertex_ai: { name: "Vertex AI Studio", url: "https://generativelanguage.googleapis.com/v1beta", type: "gemini", defaultModel: "gemini-2.5-flash" },
  aws_bedrock: { name: "AWS Bedrock Gateway", url: "http://localhost:8000/v1", type: "openai", defaultModel: "anthropic.claude-3-sonnet" },
  databricks: { name: "Databricks Models", url: "http://localhost:8001/v1", type: "openai", defaultModel: "dbrx-instruct" },
  snowflake: { name: "Snowflake Arctic", url: "http://localhost:8002/v1", type: "openai", defaultModel: "snowflake-arctic-instruct" },
  baidu: { name: "Baidu Qianfan", url: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1", type: "openai", defaultModel: "ernie-4.0" }
};

// 10+ Multi-Model Gateways
const GATEWAY_PROVIDERS = {
  openrouter: { name: "OpenRouter Gateway", url: "https://openrouter.ai/api/v1", type: "openai", defaultModel: "deepseek/deepseek-chat" },
  kie: { name: "Kie.ai Gateway", url: "https://api.kie.ai/v1", type: "openai", defaultModel: "gpt-4o-mini" },
  portkey: { name: "Portkey AI Enterprise", url: "https://api.portkey.ai/v1", type: "openai", defaultModel: "gpt-4o" },
  together: { name: "Together AI Hub", url: "https://api.together.xyz/v1", type: "openai", defaultModel: "meta-llama/Llama-3.3-70B-Instruct-Turbo" },
  fireworks: { name: "Fireworks AI", url: "https://api.fireworks.ai/inference/v1", type: "openai", defaultModel: "accounts/fireworks/models/llama-v3p3-70b-instruct" },
  chutes: { name: "Chutes AI Aggregator", url: "https://api.chutes.ai/v1", type: "openai", defaultModel: "deepseek-r1" },
  unify: { name: "Unify AI Router", url: "https://api.unify.ai/v0", type: "openai", defaultModel: "llama-3.3-70b-chat@together-ai" },
  novita: { name: "Novita AI Aggregated", url: "https://api.novita.ai/v3/openai", type: "openai", defaultModel: "meta-llama/llama-3.3-70b-instruct" },
  litellm: { name: "LiteLLM Proxy Router", url: "http://localhost:4000/v1", type: "openai", defaultModel: "gpt-4o-mini" },
  helicone: { name: "Helicone AI Gateway", url: "https://oai.helicone.ai/v1", type: "openai", defaultModel: "gpt-4o" },
  openpipe: { name: "OpenPipe Gateway", url: "https://app.openpipe.ai/api/v1", type: "openai", defaultModel: "openpipe:llama-3-8b" }
};

// 10+ Local Self-Hosting Engines
const LOCAL_HOST_ENGINES = {
  ollama: { name: "Ollama Local Engine", port: 11434, url: "http://127.0.0.1:11434/v1", type: "ollama", defaultModel: "qwen2.5-coder:latest" },
  lmstudio: { name: "LM Studio Local Host", port: 1234, url: "http://127.0.0.1:1234/v1", type: "openai", defaultModel: "local-model" },
  bionic: { name: "BionicGPT Enterprise", port: 7860, url: "http://127.0.0.1:7860/v1", type: "openai", defaultModel: "bionic-default" },
  localai: { name: "LocalAI Multi-Engine", port: 8080, url: "http://127.0.0.1:8080/v1", type: "openai", defaultModel: "gpt-4" },
  vllm: { name: "vLLM High-Speed Host", port: 8000, url: "http://127.0.0.1:8000/v1", type: "openai", defaultModel: "facebook/opt-125m" },
  jan: { name: "Jan AI Local Engine", port: 1337, url: "http://127.0.0.1:1337/v1", type: "openai", defaultModel: "mistral-ins-7b" },
  textgen: { name: "Text-Gen WebUI (Oobabooga)", port: 5000, url: "http://127.0.0.1:5000/v1", type: "openai", defaultModel: "model" },
  koboldcpp: { name: "KoboldCPP Standalone", port: 5001, url: "http://127.0.0.1:5001/v1", type: "openai", defaultModel: "kobold-model" },
  llamacpp: { name: "llama.cpp Builtin Server", port: 8080, url: "http://127.0.0.1:8080/v1", type: "openai", defaultModel: "default" },
  tabby: { name: "Tabby Local Coder", port: 8080, url: "http://127.0.0.1:8080/v1", type: "openai", defaultModel: "tabby" },
  aphrodite: { name: "Aphrodite Engine", port: 2242, url: "http://127.0.0.1:2242/v1", type: "openai", defaultModel: "aphrodite" }
};

const ALL_PROVIDERS = {
  ...DIRECT_PROVIDERS,
  ...GATEWAY_PROVIDERS,
  ...LOCAL_HOST_ENGINES,
  custom: { name: "Custom Base URL", url: "http://localhost:8000/v1", type: "openai", defaultModel: "default" }
};

// Vault Encryption
function deriveVaultKey(secret) {
  return crypto.scryptSync(secret, "shadow-salt-grey-vault", 32);
}

function readVault() {
  if (!fs.existsSync(VAULT_FILE)) return null;
  try {
    const raw = fs.readFileSync(VAULT_FILE);
    const iv = raw.subarray(0, 16);
    const tag = raw.subarray(16, 32);
    const text = raw.subarray(32);

    const key = deriveVaultKey(VAULT_ARCHIVE_SECRET);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);

    const dec = Buffer.concat([decipher.update(text), decipher.final()]);
    return JSON.parse(dec.toString("utf-8"));
  } catch {
    return null;
  }
}

function writeVault(data) {
  const content = JSON.stringify(data, null, 2);
  const iv = crypto.randomBytes(16);
  const key = deriveVaultKey(VAULT_ARCHIVE_SECRET);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);

  const cipherText = Buffer.concat([cipher.update(Buffer.from(content, "utf-8")), cipher.final()]);
  const tag = cipher.getAuthTag();

  fs.writeFileSync(VAULT_FILE, Buffer.concat([iv, tag, cipherText]));
}

function askMaskedInput(promptText) {
  return new Promise((resolve) => {
    process.stdout.write(chalk.yellow(promptText));
    let val = "";
    const isRaw = process.stdin.isRaw;

    if (process.stdin.setRawMode) process.stdin.setRawMode(true);
    process.stdin.resume();

    const onData = (chunk) => {
      const char = chunk.toString();
      if (char === "\r" || char === "\n") {
        cleanup();
        process.stdout.write("\n");
        resolve(val);
        return;
      }
      if (char === "\u0003") {
        cleanup();
        process.stdout.write("\n");
        process.exit(0);
      }
      if (char === "\u0008" || char === "\x7f") {
        if (val.length > 0) {
          val = val.slice(0, -1);
          process.stdout.write("\b \b");
        }
        return;
      }
      if (char.length === 1 && char >= " ") {
        val += char;
        process.stdout.write(chalk.magenta("*"));
      }
    };

    const cleanup = () => {
      process.stdin.removeListener("data", onData);
      if (process.stdin.setRawMode) process.stdin.setRawMode(Boolean(isRaw));
    };

    process.stdin.on("data", onData);
  });
}

async function authenticateOrInitialize() {
  let vault = readVault();

  if (!vault || !vault.masterPasswordHash) {
    console.clear();
    console.log(chalk.bold.hex("#8a2be2")("\n  ========================================================"));
    console.log(chalk.bold.hex("#8a2be2")("                GREY SECURITY VAULT SETUP                 "));
    console.log(chalk.bold.hex("#8a2be2")("  ========================================================\n"));
    console.log(chalk.dim("  First time initialization detected. Set your master password.\n"));

    let p1 = "";
    let p2 = "";

    while (true) {
      p1 = await askMaskedInput("  Create Master Password: ");
      if (!p1.trim()) {
        console.log(chalk.red("  Password cannot be empty.\n"));
        continue;
      }
      p2 = await askMaskedInput("  Confirm Master Password: ");
      if (p1 !== p2) {
        console.log(chalk.red("  Passwords do not match. Try again.\n"));
      } else {
        break;
      }
    }

    const salt = crypto.randomBytes(16).toString("hex");
    const hash = crypto.scryptSync(p1, salt, 64).toString("hex");

    writeVault({
      version: "3.2-lite",
      createdAt: new Date().toISOString(),
      salt: salt,
      masterPasswordHash: hash,
      apiKeys: []
    });

    console.log(chalk.green("\n  ✔ Vault encrypted under ShadowCreation protocol!\n"));
    await sleep(600);
    return true;
  }

  console.clear();
  console.log(chalk.bold.hex("#38bdf8")("\n  * GREY ACCESS AUTHENTICATION *"));
  console.log(chalk.dim("  Enter your master password to unlock the workspace.\n"));

  let attempts = 0;
  while (attempts < 3) {
    const inputPass = await askMaskedInput("  Master Password: ");
    const computedHash = crypto.scryptSync(inputPass, vault.salt, 64).toString("hex");

    if (computedHash === vault.masterPasswordHash) {
      console.log(chalk.green("  ✔ Access Granted.\n"));
      await sleep(300);
      return true;
    } else {
      attempts++;
      console.log(chalk.red("  Invalid password. Attempts remaining: " + (3 - attempts) + "\n"));
    }
  }

  console.log(chalk.red("  Locked out. Exiting.\n"));
  process.exit(1);
}

function loadConfig() {
  if (fs.existsSync(CONFIG_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
    } catch {}
  }
  return {
    activeProvider: null,
    activeModel: null,
    keys: {},
    baseUrls: {},
    multiModel: { enabled: false, models: [] },
    webSearch: false
  };
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2));
}

function loadGallery() {
  if (fs.existsSync(GALLERY_INDEX)) {
    try {
      return JSON.parse(fs.readFileSync(GALLERY_INDEX, "utf-8"));
    } catch {}
  }
  return [];
}

function saveGallery(list) {
  fs.writeFileSync(GALLERY_INDEX, JSON.stringify(list, null, 2));
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function getAtmosphere() {
  const h = new Date().getHours();
  const isDay = h >= 6 && h < 18;
  return {
    isDay: isDay,
    timeLabel: new Date().toLocaleTimeString(),
    orb: isDay ? "( ☼ SUN ☼ )" : "( ☽ MOON ☾ )",
    orbColor: isDay ? chalk.hex("#facc15").bold : chalk.hex("#e0e7ff").bold,
    skyColor: isDay ? chalk.hex("#38bdf8") : chalk.hex("#4338ca"),
    grassColor: isDay ? chalk.hex("#4ade80") : chalk.hex("#15803d")
  };
}

// Animated Living Atmosphere (~1.4s smooth playback)
async function playLivingAtmosphere(config) {
  process.stdout.write("\x1B[?25l"); // Hide cursor
  const env = getAtmosphere();

  const logoLines = [
    "  ██████╗ ██████╗ ███████╗██╗   ██╗",
    " ██╔════╝ ██╔══██╗██╔════╝╚██╗ ██╔╝",
    " ██║  ███╗██████╔╝█████╗   ╚████╔╝ ",
    " ██║   ██║██╔══██╗██╔══╝    ╚██╔╝  ",
    " ╚██████╔╝██║  ██║███████╗   ██║   ",
    "  ╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝   "
  ];

  const cloudFrames = [
    "    ☁ ☁ ☁                ☁ ☁                  *      ",
    "       ☁ ☁ ☁                ☁ ☁           *          ",
    "          ☁ ☁ ☁                ☁ ☁            *      ",
    "             ☁ ☁ ☁                ☁ ☁                ",
    "  .             ☁ ☁ ☁                ☁ ☁         *   ",
    "     *             ☁ ☁ ☁                ☁ ☁          ",
    "        .             ☁ ☁ ☁                ☁ ☁       ",
    "           *             ☁ ☁ ☁                ☁ ☁    "
  ];

  const windTrails = [
    "    ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~ ≋ ≋ ≋ ༄  ",
    "         ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~ ≋ ≋ ≋",
    "  .           ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~",
    "       *           ~ ~ ~ ≋ ≋ ≋ ༄                     ",
    "  ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~ ≋ ≋ ≋ ༄  * ",
    "         ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~ ≋ ≋ ≋",
    "  *           ~ ~ ~ ≋ ≋ ≋ ༄                     ~ ~ ~",
    "       .           ~ ~ ~ ≋ ≋ ≋ ༄                     "
  ];

  const grassFrames = [
    "wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//",
    "\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw",
    "/|/\\wWw\\|/\\wWw\\|/\\wWw/|/\\wWw\\|/\\wWw\\|/\\wWw\\|/\\wWw\\|/\\wWw",
    "wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\",
    "wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//",
    "\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw\\|//wWw/|/\\wWw",
    "/|/\\wWw\\|/\\wWw\\|/\\wWw/|/\\wWw\\|/\\wWw\\|/\\wWw\\|/\\wWw\\|/\\wWw",
    "wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\wWw\\|/\\wWw\\|//wWw/|/\\"
  ];

  for (let f = 0; f < cloudFrames.length; f++) {
    console.clear();
    console.log(env.skyColor("  " + cloudFrames[f]));
    console.log("             " + env.orbColor(env.orb) + chalk.dim("  [" + env.timeLabel + "]"));
    console.log(env.skyColor(windTrails[f]));

    for (let i = 0; i < logoLines.length; i++) {
      if (f % 2 === 0) {
        console.log(chalk.hex("#a855f7").bold(logoLines[i]));
      } else {
        console.log(chalk.hex("#00ffff").bold(logoLines[i]));
      }
    }

    console.log(env.grassColor(grassFrames[f]));
    console.log(env.grassColor.dim("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"));
    await sleep(110);
  }

  process.stdout.write("\x1B[?25h"); // Show cursor

  console.log(chalk.bold.hex("#38bdf8")("\n   * GREY Multi-Intelligence Node v3.2 Lite *"));
  console.log(chalk.gray("   ----------------------------------------------------------"));
  console.log("   " + chalk.hex("#a855f7")("Active Provider: ") + chalk.cyan(config.activeProvider || "[None - Use /api or /lh]"));
  console.log("   " + chalk.hex("#a855f7")("Active Model   : ") + chalk.white(config.activeModel || "[None - Use /model]"));
  const consensusTag = config.multiModel && config.multiModel.enabled
    ? chalk.green("[" + config.multiModel.models.length + " Models Active]")
    : chalk.dim("[Single Model]");
  console.log("   " + chalk.hex("#a855f7")("Consensus Hub  : ") + consensusTag);
  console.log(chalk.gray("   ----------------------------------------------------------"));
  console.log(chalk.bold.yellow("   COMMANDS:"));
  console.log(chalk.dim("   /api      ") + "- Configure Direct Foundation & Gateway Providers");
  console.log(chalk.dim("   /lh       ") + "- Switch & bind Local Hosting Engines (Ollama, LM Studio...)");
  console.log(chalk.dim("   /model    ") + "- View & switch between all models on active provider");
  console.log(chalk.dim("   /mm       ") + "- Multi-Model parallel consensus mode");
  console.log(chalk.dim("   /wse      ") + "- Toggle DuckDuckGo live web research");
  console.log(chalk.dim("   /upload   ") + "- Attach local files, scripts, or documents to prompt");
  console.log(chalk.dim("   /gallery  ") + "- View recorded visual assets");
  console.log(chalk.dim("   /history  ") + "- Restore an archived session");
  console.log(chalk.dim("   /new      ") + "- Reset and start a fresh session");
  console.log(chalk.dim("   /apicreate") + "- Generate an encrypted Shadow API key");
  console.log(chalk.dim("   /apilist  ") + "- List created Shadow keys (Requires Master Password)");
  console.log(chalk.dim("   /exit     ") + "- Save session and exit GREY");
  console.log(chalk.gray("   ----------------------------------------------------------\n"));
}

async function retroMenu(title, options) {
  return new Promise((resolve) => {
    let selected = 0;
    const isRaw = process.stdin.isRaw;
    if (process.stdin.setRawMode) process.stdin.setRawMode(true);
    process.stdin.resume();

    const render = () => {
      process.stdout.write("\x1B[?25l");
      console.log("\n" + chalk.bold.hex("#38bdf8")("--- " + title + " ---"));
      options.forEach((opt, idx) => {
        const badge = opt.tag ? " " + opt.tag : "";
        if (idx === selected) {
          console.log(
            chalk.hex("#00ffff").bold("  > ") +
              chalk.black.bgHex("#38bdf8")(" " + opt.label + " ") +
              badge +
              " " +
              chalk.dim(opt.sub || "")
          );
        } else {
          console.log("    " + chalk.white(opt.label) + badge + " " + chalk.gray(opt.sub || ""));
        }
      });
      console.log(chalk.gray("--------------------------------------------------\n"));
    };

    render();

    const onData = (chunk) => {
      const key = chunk.toString();
      if (key === "\r" || key === "\n") {
        cleanup();
        resolve(options[selected].value);
        return;
      }
      if (key === "\u0003") {
        cleanup();
        resolve(null);
        return;
      }
      if (key === "\u001b[A" || key === "w" || key === "W") {
        selected = (selected - 1 + options.length) % options.length;
        clearMenu();
        render();
        return;
      }
      if (key === "\u001b[B" || key === "s" || key === "S") {
        selected = (selected + 1) % options.length;
        clearMenu();
        render();
        return;
      }
    };

    const clearMenu = () => {
      process.stdout.write("\x1B[" + (options.length + 4) + "A\x1B[0J");
    };

    const cleanup = () => {
      process.stdin.removeListener("data", onData);
      if (process.stdin.setRawMode) process.stdin.setRawMode(Boolean(isRaw));
      process.stdout.write("\x1B[?25h");
    };

    process.stdin.on("data", onData);
  });
}

function askQuestion(query, defVal = "") {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const pText = defVal ? chalk.yellow(query) + chalk.dim(" [" + defVal + "]") + ": " : chalk.yellow(query) + ": ";
  return new Promise((resolve) =>
    rl.question(pText, (ans) => {
      rl.close();
      resolve(ans.trim() || defVal);
    })
  );
}

// Scrapes models live from active endpoint
async function fetchModels(provider, config) {
  const provMeta = ALL_PROVIDERS[provider];
  if (!provMeta) return [];

  const apiKey = config.keys ? config.keys[provider] : null;
  const baseUrl = (config.baseUrls && config.baseUrls[provider]) ? config.baseUrls[provider] : provMeta.url;

  process.stdout.write(chalk.dim("\n  Interrogating " + provMeta.name + "... "));

  try {
    if (provMeta.type === "gemini") {
      const target = baseUrl + "/models?key=" + apiKey;
      const res = await fetch(target);
      if (!res.ok) throw new Error("HTTP " + res.status);
      const d = await res.json();
      process.stdout.write(chalk.green("OK\n"));
      return (d.models || [])
        .filter((m) => m.supportedGenerationMethods && m.supportedGenerationMethods.includes("generateContent"))
        .map((m) => {
          const id = m.name.replace("models/", "");
          return {
            id: id,
            name: m.displayName || id,
            isFree: id.includes("flash") || id.includes("exp")
          };
        });
    }

    if (provMeta.type === "ollama") {
      const targetUrl = baseUrl.replace(/\/v1\/?$/, "") + "/api/tags";
      const res = await fetch(targetUrl);
      if (!res.ok) throw new Error("HTTP " + res.status);
      const d = await res.json();
      process.stdout.write(chalk.green("OK\n"));
      return (d.models || []).map((m) => ({ id: m.name, name: m.name, isFree: true }));
    }

    if (provMeta.type === "anthropic") {
      const res = await fetch("https://api.anthropic.com/v1/models", {
        headers: {
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01"
        }
      });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const d = await res.json();
      process.stdout.write(chalk.green("OK\n"));
      return (d.data || []).map((m) => ({ id: m.id, name: m.display_name || m.id, isFree: false }));
    }

    const cleanBase = baseUrl.replace(/\/chat\/completions\(/, "").replace(/\/\)/, "");
    const targetUrl = cleanBase + "/models";
    const headers = { "Content-Type": "application/json" };
    if (apiKey) headers["Authorization"] = "Bearer " + apiKey;

    const res = await fetch(targetUrl, { headers: headers });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const d = await res.json();
    process.stdout.write(chalk.green("OK\n"));

    const rawList = Array.isArray(d) ? d : (d.data || d.models || []);
    return rawList.map((m) => {
      const id = m.id || m.name;
      const isFree = id.includes(":free") || id.includes("free");
      return { id: id, name: m.name || id, isFree: Boolean(isFree) };
    });
  } catch (err) {
    process.stdout.write(chalk.yellow("catalog applied (" + err.message + ")\n"));
    return provMeta.fallbackModels || [{ id: provMeta.defaultModel, name: provMeta.defaultModel, isFree: true }];
  }
}

// Thinking Spinner Helper
class ThinkingSpinner {
  constructor(message = "GREY is analyzing...") {
    this.message = message;
    this.frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
    this.idx = 0;
    this.timer = null;
  }

  start() {
    process.stdout.write("\x1B[?25l");
    this.timer = setInterval(() => {
      const f = this.frames[this.idx % this.frames.length];
      process.stdout.write("\r" + chalk.hex("#38bdf8")(f) + " " + chalk.dim(this.message) + " ");
      this.idx++;
    }, 75);
  }

  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
      process.stdout.write("\r\x1B[K\x1B[?25h");
    }
  }
}

// Inference Engine (Unified streaming)
async function* streamUnifiedAI(messages, model, config, signal) {
  const provider = config.activeProvider;
  const provMeta = ALL_PROVIDERS[provider] || ALL_PROVIDERS.gemini;
  const apiKey = config.keys ? config.keys[provider] : null;
  const baseUrl = (config.baseUrls && config.baseUrls[provider]) ? config.baseUrls[provider] : provMeta.url;

  if (provMeta.type === "gemini") {
    let cleanModel = model.replace("google/", "").replace("models/", "");
    if (cleanModel.includes("deepseek") || cleanModel.includes("gpt") || cleanModel.includes("claude")) {
      cleanModel = "gemini-2.5-flash";
    }

    const url = baseUrl + "/models/" + cleanModel + ":streamGenerateContent?alt=sse&key=" + apiKey;
    const contents = messages
      .filter((m) => m.role !== "system")
      .map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: contents }),
      signal: signal
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error("Gemini HTTP " + res.status + ": " + errText);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop();

      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.startsWith("data: ")) {
          try {
            const j = JSON.parse(line.slice(6));
            const t = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts && j.candidates[0].content.parts[0] ? j.candidates[0].content.parts[0].text : "";
            if (t) yield t;
          } catch {}
        }
      }
    }
    return;
  }

  // Universal OpenAI-compatible stream
  const cleanBase = baseUrl.replace(/\/$/, "");
  const targetUrl = cleanBase.endsWith("/chat/completions") ? cleanBase : cleanBase + "/chat/completions";
  const headers = {
    "Content-Type": "application/json",
    "HTTP-Referer": "https://github.com/grey-cli",
    "X-Title": "GREY"
  };
  if (apiKey) headers["Authorization"] = "Bearer " + apiKey;

  const res = await fetch(targetUrl, {
    method: "POST",
    headers: headers,
    body: JSON.stringify({ model: model, messages: messages, stream: true }),
    signal: signal
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error("API Error [" + res.status + "]: " + errText);
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop();

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      if (line.startsWith("data: ") && line.trim() !== "data: [DONE]") {
        try {
          const j = JSON.parse(line.slice(6));
          const t = j.choices && j.choices[0] && j.choices[0].delta ? j.choices[0].delta.content : "";
          if (t) yield t;
        } catch {}
      }
    }
  }
}

async function callSingle(messages, model, config) {
  const provider = config.activeProvider;
  const provMeta = ALL_PROVIDERS[provider] || ALL_PROVIDERS.gemini;
  const apiKey = config.keys ? config.keys[provider] : null;
  const baseUrl = (config.baseUrls && config.baseUrls[provider]) ? config.baseUrls[provider] : provMeta.url;

  if (provMeta.type === "gemini") {
    let cleanModel = model.replace("google/", "").replace("models/", "");
    if (cleanModel.includes("deepseek") || cleanModel.includes("gpt") || cleanModel.includes("claude")) {
      cleanModel = "gemini-2.5-flash";
    }

    const url = baseUrl + "/models/" + cleanModel + ":generateContent?key=" + apiKey;
    const contents = messages
      .filter((m) => m.role !== "system")
      .map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      }));

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: contents })
    });
    if (!res.ok) return "";
    const d = await res.json();
    return (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts && d.candidates[0].content.parts[0])
      ? d.candidates[0].content.parts[0].text
      : "";
  }

  const cleanBase = baseUrl.replace(/\/$/, "");
  const targetUrl = cleanBase.endsWith("/chat/completions") ? cleanBase : cleanBase + "/chat/completions";
  const headers = { "Content-Type": "application/json" };
  if (apiKey) headers["Authorization"] = "Bearer " + apiKey;

  const res = await fetch(targetUrl, {
    method: "POST",
    headers: headers,
    body: JSON.stringify({ model: model, messages: messages, stream: false })
  });
  if (!res.ok) return "";
  const d = await res.json();
  return (d.choices && d.choices[0] && d.choices[0].message) ? d.choices[0].message.content : "";
}

async function searchWeb(query) {
  try {
    const url = "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(query);
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
    });
    if (!res.ok) return null;
    const html = await res.text();
    const matches = [];
    const openTag = 'class="result__snippet';
    const closeTag = "";
    let cursor = 0;

    while (matches.length < 3) {
      const startIdx = html.indexOf(openTag, cursor);
      if (startIdx === -1) break;
      const contentStart = html.indexOf(">", startIdx);
      if (contentStart === -1) break;
      const endIdx = html.indexOf(closeTag, contentStart);
      if (endIdx === -1) break;

      let snippet = html.substring(contentStart + 1, endIdx);
      snippet = snippet.replace(/<[^>]+>/g, "").trim();
      if (snippet) matches.push(snippet);
      cursor = endIdx + closeTag.length;
    }

    return matches.length > 0 ? matches.join("\n- ") : null;
  } catch {
    return null;
  }
}

function getAllSessions() {
  const files = fs.readdirSync(SESSIONS_DIR).filter((f) => f.endsWith(".json"));
  return files.map((f) => JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, f), "utf-8")));
}

function persistSession(session) {
  fs.writeFileSync(path.join(SESSIONS_DIR, session.id + ".json"), JSON.stringify(session, null, 2));
}

// Main Command REPL
async function main() {
  await authenticateOrInitialize();

  const config = loadConfig();

  let activeSession = {
    id: Date.now().toString(),
    title: "Fresh Session",
    createdAt: new Date().toISOString(),
    messages: [
      {
        role: "system",
        content:
          "You are GREY: an elite consensus engine and developer companion. Be direct, avoid redundant conversational filler, format code cleanly with double line-breaks."
      }
    ]
  };

  await playLivingAtmosphere(config);

  let activeAbort = null;
  let isThinking = false;

  const startRepl = () => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
      prompt: chalk.cyan.bold("User ❯ ")
    });

    rl.prompt();

    rl.on("line", async (line) => {
      const input = line.trim();

      if (isThinking) {
        if (input === "/skip") {
          if (activeAbort) {
            activeAbort.abort();
            console.log(chalk.yellow("\n[Stream halted by user]"));
          }
        }
        return;
      }

      if (!input) {
        rl.prompt();
        return;
      }

      if (input === "/exit" || input === "exit") {
        persistSession(activeSession);
        console.log(chalk.hex("#8a2be2")("\nSession saved. Exiting GREY.\n"));
        process.exit(0);
      }

      if (input === "/new") {
        persistSession(activeSession);
        activeSession = {
          id: Date.now().toString(),
          title: "Fresh Session",
          createdAt: new Date().toISOString(),
          messages: [activeSession.messages[0]]
        };
        await playLivingAtmosphere(config);
        console.log(chalk.green("Clean session ready.\n"));
        rl.prompt();
        return;
      }

      // /api — Direct & Gateway Providers
      if (input === "/api") {
        rl.close();

        const category = await retroMenu("SELECT PROVIDER ECOSYSTEM", [
          { label: "Direct AI Providers (30+)", sub: "- Google Gemini, OpenAI, Anthropic, Groq, DeepSeek, xAI...", value: "direct" },
          { label: "Multi-Model Gateways (10+)", sub: "- OpenRouter, Kie.ai, Portkey, Together, Fireworks...", value: "gateway" }
        ]);

        const selectedMap = category === "direct" ? DIRECT_PROVIDERS : GATEWAY_PROVIDERS;
        const provChoices = Object.entries(selectedMap).map(([k, v]) => ({
          label: v.name,
          sub: "(" + v.url + ")",
          value: k
        }));

        const selectedProv = await retroMenu("CHOOSE AI PROVIDER", provChoices);
        if (selectedProv) {
          const key = await askMaskedInput("Enter API Key for " + selectedProv.toUpperCase() + " (Masked): ");
          const provMeta = ALL_PROVIDERS[selectedProv];

          config.keys = config.keys || {};
          config.baseUrls = config.baseUrls || {};
          config.keys[selectedProv] = key;
          config.baseUrls[selectedProv] = provMeta.url;
          config.activeProvider = selectedProv;
          config.activeModel = provMeta.defaultModel;

          saveConfig(config);
          console.log(
            chalk.green("\n✔ " + selectedProv.toUpperCase() + " activated! Active model set to: " + config.activeModel + "\n")
          );
        }
        startRepl();
        return;
      }

      // /lh — Local Hosting Engines
      if (input === "/lh") {
        rl.close();

        const hostChoices = Object.entries(LOCAL_HOST_ENGINES).map(([k, v]) => ({
          label: v.name,
          sub: "[Port " + v.port + "] " + v.url,
          value: k
        }));

        const pickedLocal = await retroMenu("LOCAL AI HOSTING APPS (10+ ENGINES)", hostChoices);
        if (pickedLocal) {
          const engine = LOCAL_HOST_ENGINES[pickedLocal];
          const customPort = await askQuestion("Enter local server port", String(engine.port));
          const localUrl = "http://127.0.0.1:" + customPort + "/v1";

          config.activeProvider = pickedLocal;
          config.baseUrls = config.baseUrls || {};
          config.baseUrls[pickedLocal] = localUrl;
          config.keys = config.keys || {};
          config.keys[pickedLocal] = "local-token";
          config.activeModel = engine.defaultModel;

          saveConfig(config);
          console.log(
            chalk.green("\n✔ Connected to " + engine.name + " on " + localUrl + " (Model: " + config.activeModel + ")\n")
          );
        }
        startRepl();
        return;
      }

      // /model — Dynamic Models
      if (input === "/model") {
        rl.close();
        if (!config.activeProvider) {
          console.log(chalk.red("\nNo provider active! Set one up via /api or /lh first.\n"));
          startRepl();
          return;
        }

        const remoteModels = await fetchModels(config.activeProvider, config);
        const modelOptions = remoteModels.slice(0, 40).map((m) => ({
          label: m.name.length > 32 ? m.name.slice(0, 30) + ".." : m.name,
          tag: m.isFree ? chalk.bgGreen.black(" FREE ") : chalk.bgYellow.black("  $   "),
          sub: "(" + m.id + ")",
          value: m.id
        }));

        const pickedModel = await retroMenu("AVAILABLE MODELS ON " + config.activeProvider.toUpperCase(), modelOptions);
        if (pickedModel) {
          config.activeModel = pickedModel;
          saveConfig(config);
          console.log(chalk.green("\n✔ Active model set to: " + pickedModel + "\n"));
        }
        startRepl();
        return;
      }

      // /mm — Multi-Model Consensus
      if (input === "/mm") {
        rl.close();
        const choice = await retroMenu("ENABLE MULTI-MODEL CONSENSUS?", [
          { label: "YES", sub: "- Concurrently stream and synthesize from multiple models", value: true },
          { label: "NO", sub: "- Use primary model only", value: false }
        ]);

        if (choice) {
          const list = await fetchModels(config.activeProvider, config);
          if (list.length === 0) {
            console.log(chalk.red("\nNo models discovered. Setup /api or /lh first.\n"));
          } else {
            const multiOpts = list.slice(0, 20).map((m) => ({
              label: m.id,
              tag: m.isFree ? chalk.bgGreen.black(" FREE ") : chalk.bgYellow.black("  $   "),
              value: m.id
            }));
            const m1 = await retroMenu("SELECT FIRST CONSENSUS MODEL", multiOpts);
            const m2 = await retroMenu("SELECT SECOND CONSENSUS MODEL", multiOpts);
            config.multiModel = { enabled: true, models: [m1, m2] };
            saveConfig(config);
            console.log(chalk.green("\n✔ Consensus squad locked: " + m1 + " + " + m2 + "\n"));
          }
        } else {
          config.multiModel.enabled = false;
          saveConfig(config);
          console.log(chalk.yellow("\nMulti-model consensus deactivated.\n"));
        }
        startRepl();
        return;
      }

      // /wse — Web Search Toggle
      if (input === "/wse") {
        rl.close();
        const wChoice = await retroMenu("LIVE DUCKDUCKGO WEB RESEARCH?", [
          { label: "YES", sub: "- Queries live web context on prompts", value: true },
          { label: "NO", sub: "- Model weights only", value: false }
        ]);
        config.webSearch = Boolean(wChoice);
        saveConfig(config);
        console.log(chalk.green("\n✔ DuckDuckGo Web Search is now " + (config.webSearch ? "ACTIVE" : "DISABLED") + ".\n"));
        startRepl();
        return;
      }

      // /upload — Fixed EISDIR Directory & Empty Input handling
      if (input === "/upload" || input.startsWith("/upload ")) {
        let target = input.replace("/upload", "").trim();

        if (!target) {
          rl.close();
          target = await askQuestion("Enter path to file or document to upload");
          startRepl();
          if (!target) {
            console.log(chalk.yellow("\nUpload cancelled.\n"));
            rl.prompt();
            return;
          }
        }

        const resolved = path.resolve(process.cwd(), target);

        if (fs.existsSync(resolved)) {
          const stat = fs.statSync(resolved);

          if (stat.isDirectory()) {
            console.log(chalk.yellow("\n'" + target + "' is a directory. Files in directory:"));
            const files = fs.readdirSync(resolved).slice(0, 10);
            files.forEach((f) => console.log("  - " + f));
            console.log(chalk.dim("Specify an exact file path to upload (e.g. /upload " + target + "/filename.ext)\n"));
            rl.prompt();
            return;
          }

          const ext = path.extname(resolved).toLowerCase();
          const isImg = [".png", ".jpg", ".jpeg", ".webp", ".svg"].includes(ext);

          if (isImg) {
            const gallery = loadGallery();
            gallery.unshift({ name: path.basename(resolved), type: "Local Image", path: resolved, addedAt: new Date().toISOString() });
            saveGallery(gallery);
            console.log(chalk.green("\n✔ Image added to /gallery: " + path.basename(resolved) + "\n"));
          } else {
            const data = fs.readFileSync(resolved, "utf-8");
            activeSession.messages.push({
              role: "user",
              content: "Attached Document: `" + path.basename(resolved) + "`\n```\n" + data + "\n```"
            });
            console.log(chalk.green("\n✔ Attached " + path.basename(resolved) + " (" + data.length + " bytes) to context!\n"));
          }
        } else {
          console.log(chalk.red("\nTarget file not found at: " + resolved + "\n"));
        }
        rl.prompt();
        return;
      }

      // /apicreate — Shadow Key Creation
      if (input === "/apicreate") {
        rl.close();
        const proceedChoice = await retroMenu("CREATE NEW SHADOW API KEY?", [
          { label: "YES", sub: "- Generate a new secure GREY API key", value: true },
          { label: "NO", sub: "- Cancel", value: false }
        ]);

        if (proceedChoice) {
          const apiName = await askQuestion("Enter a friendly name for this API Key");
          if (!apiName) {
            console.log(chalk.red("\nAPI Key name cannot be empty.\n"));
            startRepl();
            return;
          }

          const rawRandom = crypto.randomBytes(16).toString("hex");
          const generatedKey = "sh-grey-" + rawRandom;

          const vault = readVault();
          vault.apiKeys = vault.apiKeys || [];
          vault.apiKeys.push({
            name: apiName,
            key: generatedKey,
            createdAt: new Date().toISOString()
          });
          writeVault(vault);

          console.clear();
          console.log(chalk.bold.hex("#00ff66")("\n  =============================================================================="));
          console.log(chalk.bold.hex("#00ff66")("                          NEW SHADOW API KEY GENERATED                          "));
          console.log(chalk.bold.hex("#00ff66")("  ==============================================================================\n"));
          console.log("  " + chalk.dim("Label:") + " " + chalk.bold.white(apiName));
          console.log("  " + chalk.dim("Key  :") + " " + chalk.bold.hex("#00ffff")(generatedKey));
          console.log("  " + chalk.dim("Vault:") + " " + chalk.green("Encrypted in vault.bin (ShadowCreation)\n"));
          console.log(chalk.gray("  ----------------------------------------------------------------------------"));

          await askQuestion(chalk.yellow("  Press ENTER once copied to close..."));
          console.clear();
          await playLivingAtmosphere(config);
        }
        startRepl();
        return;
      }

      // /apilist — Protected API Key Ledger
      if (input === "/apilist") {
        rl.close();
        const vault = readVault();
        if (!vault || !vault.apiKeys || vault.apiKeys.length === 0) {
          console.log(chalk.dim("\nNo Shadow API Keys stored in vault.\n"));
          startRepl();
          return;
        }

        const entered = await askMaskedInput("Enter Master Password to view keys: ");
        const computedHash = crypto.scryptSync(entered, vault.salt, 64).toString("hex");

        if (computedHash !== vault.masterPasswordHash) {
          console.log(chalk.red("\nAccess denied: Incorrect master password.\n"));
        } else {
          console.log(chalk.bold.hex("#00ffff")("\n--- SHADOW API VAULT DIRECTORY ---"));
          vault.apiKeys.forEach((item, idx) => {
            console.log("  [" + (idx + 1) + "] " + chalk.bold.white(item.name.padEnd(20)) + " -> " + chalk.green(item.key));
          });
          console.log(chalk.gray("--------------------------------------------------\n"));
        }
        startRepl();
        return;
      }

      // /gallery
      if (input === "/gallery") {
        rl.close();
        const gallery = loadGallery();
        if (gallery.length === 0) {
          console.log(chalk.dim("\nNo visual assets recorded.\n"));
        } else {
          console.log(chalk.bold.hex("#38bdf8")("\n--- VISUAL LEDGER / GALLERY ---"));
          gallery.forEach((item, i) => {
            console.log("  [" + (i + 1) + "] " + chalk.cyan(item.name) + " | " + chalk.dim(item.path));
          });
          console.log(chalk.gray("-------------------------------\n"));
        }
        startRepl();
        return;
      }

      // /history
      if (input === "/history") {
        rl.close();
        const sessions = getAllSessions();
        if (sessions.length === 0) {
          console.log(chalk.dim("\nNo saved sessions found.\n"));
        } else {
          const sOpts = sessions.slice(0, 15).map((s) => ({
            label: s.title,
            sub: "(" + s.createdAt.split("T")[0] + ")",
            value: s
          }));
          const picked = await retroMenu("RESTORE ARCHIVED SESSION", sOpts);
          if (picked) {
            persistSession(activeSession);
            activeSession = picked;
            console.log(chalk.green('✔ Restored session: "' + picked.title + '"\n'));
          }
        }
        startRepl();
        return;
      }

      // Safeguard
      if (!config.activeProvider) {
        console.log(chalk.red("\nNo active AI provider configured! Type /api or /lh to select one.\n"));
        rl.prompt();
        return;
      }

      if (activeSession.messages.length === 1) {
        activeSession.title = input.slice(0, 32).replace(/\n/g, " ");
      }

      let finalUserMessage = input;

      if (config.webSearch) {
        process.stdout.write(chalk.cyan("\n[DuckDuckGo] Interrogating web context... "));
        const searchContext = await searchWeb(input);
        if (searchContext) {
          process.stdout.write(chalk.green("OK\n"));
          finalUserMessage = "[Live Web Search Context:\n- " + searchContext + "]\n\nUser Question: " + input;
        } else {
          process.stdout.write(chalk.dim("No extra info\n"));
        }
      }

      activeSession.messages.push({ role: "user", content: finalUserMessage });
      isThinking = true;
      activeAbort = new AbortController();

      // Multi-Model Consensus Stream Execution
      if (config.multiModel && config.multiModel.enabled && config.multiModel.models && config.multiModel.models.length > 1) {
        console.log(
          chalk.bold.hex("#38bdf8")(
            "\nConsulting Multi-Model Consensus (" + config.multiModel.models.join(", ") + ")..."
          )
        );
        const rawAnswers = [];
        for (let idx = 0; idx < config.multiModel.models.length; idx++) {
          const mId = config.multiModel.models[idx];
          process.stdout.write(chalk.dim("  -> Querying " + mId + "... "));
          const ans = await callSingle(activeSession.messages, mId, config);
          rawAnswers.push({ model: mId, ans: ans });
          process.stdout.write(chalk.green("OK\n"));
        }

        const synthesisPayload = [
          {
            role: "system",
            content:
              "You are GREY Consensus Synthesizer. Multiple models gave answers to the user's prompt. Formulate ONE flawless, unified, non-repetitive, master answer."
          },
          {
            role: "user",
            content:
              'User Question: "' +
              input +
              '"\n\nModel Responses:\n' +
              rawAnswers.map((r, i) => "--- Model " + (i + 1) + " (" + r.model + ") ---\n" + r.ans).join("\n\n")
          }
        ];

        process.stdout.write(
          "\n" +
            chalk.bold.hex("#a855f7")("GREY:") +
            " " +
            chalk.green.bold("[Consensus Master Stream]\n") +
            chalk.gray("--------------------------------------------------\n")
        );

        let fullReply = "";
        try {
          const leadModel = config.activeModel || config.multiModel.models[0];
          for await (const chunk of streamUnifiedAI(
            synthesisPayload,
            leadModel,
            config,
            activeAbort.signal
          )) {
            fullReply += chunk;
            process.stdout.write(chunk);
            await sleep(10);
          }
          process.stdout.write("\n" + chalk.gray("--------------------------------------------------") + "\n\n");
          activeSession.messages.push({ role: "assistant", content: fullReply });
          persistSession(activeSession);
        } catch (e) {
          console.log(chalk.red("Consensus synthesis aborted: " + e.message + "\n"));
        }
      } else {
        // Single Model Direct Stream Execution
        const targetModel = config.activeModel || (ALL_PROVIDERS[config.activeProvider] ? ALL_PROVIDERS[config.activeProvider].defaultModel : "gemini-2.5-flash");

        const spinner = new ThinkingSpinner("GREY is thinking...");
        spinner.start();

        let fullReply = "";
        let hasStartedStreaming = false;

        try {
          for await (const chunk of streamUnifiedAI(activeSession.messages, targetModel, config, activeAbort.signal)) {
            if (!hasStartedStreaming) {
              spinner.stop();
              process.stdout.write(
                "\n" +
                  chalk.bold.hex("#a855f7")("GREY:") +
                  "\n" +
                  chalk.gray("--------------------------------------------------\n")
              );
              hasStartedStreaming = true;
            }
            fullReply += chunk;
            process.stdout.write(chunk);
            await sleep(10);
          }

          if (!hasStartedStreaming) {
            spinner.stop();
          }

          process.stdout.write("\n" + chalk.gray("--------------------------------------------------") + "\n\n");
          activeSession.messages.push({ role: "assistant", content: fullReply });
          persistSession(activeSession);
        } catch (e) {
          spinner.stop();
          if (e.name === "AbortError") {
            activeSession.messages.push({ role: "assistant", content: fullReply });
            persistSession(activeSession);
            console.log(chalk.yellow("\n[Stream halted]\n"));
          } else {
            console.log(chalk.red("\n[Execution Error] " + e.message + "\n"));
          }
        }
      }

      isThinking = false;
      activeAbort = null;
      rl.prompt();
    });

    rl.on("SIGINT", () => {
      if (isThinking && activeAbort) {
        activeAbort.abort();
      } else {
        persistSession(activeSession);
        console.log(chalk.hex("#8a2be2")("\nSession saved. Exiting GREY.\n"));
        process.exit(0);
      }
    });
  };

  startRepl();
}

main();