@echo off
setlocal enabledelayedexpansion

title GREY CLI - Automatic Setup
color 0b

echo ========================================================
echo               GREY CLI AUTO-INSTALLER (WINDOWS)
echo ========================================================
echo.

:: 1. Auto-detect and move into this script's directory
cd /d "%~dp0"
echo [*] Working Directory: %CD%
echo.

:: 2. Check if Node.js is installed
where node >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [X] Node.js is NOT installed!
    echo     Please install Node.js from https://nodejs.org and re-run.
    echo.
    pause
    exit /b 1
)

:: 3. Check if npm is available
where npm >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [X] npm is NOT found in PATH!
    echo.
    pause
    exit /b 1
)

echo [*] Node Version: 
node -v
echo [*] NPM Version:
npm -v
echo.

:: 4. Temporarily enable script execution policy to prevent ps1 blocks
echo [*] Configuring execution permissions...
powershell -Command "Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force" >nul 2>&1

:: 5. Install dependencies
echo [*] Installing dependencies from package.json...
call npm install
if %ERRORLEVEL% neq 0 (
    echo.
    echo [X] npm install failed. Check your internet connection.
    pause
    exit /b 1
)
echo [V] Dependencies installed successfully.
echo.

:: 6. Register 'grey' globally on the machine
echo [*] Registering 'grey' command globally...
call npm link
if %ERRORLEVEL% neq 0 (
    echo.
    echo [!] Standard link failed. Attempting global forced linking...
    call npm install -g .
)
echo [V] Global registration complete.
echo.

echo ========================================================
echo            SETUP COMPLETE! GREY IS READY.
echo ========================================================
echo.
echo You can now open ANY terminal or command prompt and type:
echo.
echo       grey
echo.
echo ========================================================
echo.

set /p START_NOW="Do you want to launch GREY now? (Y/N): "
if /i "!START_NOW!"=="Y" (
    cls
    call grey
)

endlocal
pause