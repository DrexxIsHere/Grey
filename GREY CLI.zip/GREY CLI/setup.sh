#!/data/data/com.termux/files/usr/bin/bash

# Termux / Linux Auto-Setup Script for GREY CLI
clear

echo "\033[1;35m========================================================\033[0m"
echo "\033[1;36m           GREY CLI AUTO-INSTALLER (ANDROID/TERMUX)     \033[0m"
echo "\033[1;35m========================================================\033[0m"
echo ""

# 1. Auto-detect script directory and navigate to it
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"
echo "\033[0;32m[*] Working Directory:\033[0m $PWD"
echo ""

# 2. Update Termux repositories and install Node.js + Git if missing
echo "\033[0;33m[*] Checking system packages...\033[0m"
if ! command -v node >/dev/null 2>&1; then
    echo "\033[0;33m[*] Installing Node.js...\033[0m"
    pkg update -y && pkg install nodejs git -y
else
    echo "\033[0;32m[V] Node.js is already installed:\033[0m $(node -v)"
fi

# 3. Ensure execution permission on index.js
echo "\033[0;33m[*] Granting execution rights to index.js...\033[0m"
chmod +x index.js

# 4. Install npm dependencies
echo "\033[0;33m[*] Installing npm packages...\033[0m"
npm install
if [ $? -ne 0 ]; then
    echo "\033[0;31m[X] npm install failed. Please check your connection.\033[0m"
    exit 1
fi

# 5. Link globally so 'grey' works anywhere in Termux
echo "\033[0;33m[*] Registering 'grey' binary globally...\033[0m"
npm link
if [ $? -ne 0 ]; then
    echo "\033[0;33m[*] Retrying with global prefix install...\033[0m"
    npm install -g .
fi

# 6. Fallback symlink to Termux bin path
if [ -d "/data/data/com.termux/files/usr/bin" ]; then
    ln -sf "$SCRIPT_DIR/index.js" /data/data/com.termux/files/usr/bin/grey
fi

echo ""
echo "\033[1;35m========================================================\033[0m"
echo "\033[1;32m         SETUP COMPLETE! GREY IS READY ON ANDROID.     \033[0m"
echo "\033[1;35m========================================================\033[0m"
echo ""
echo "You can now run GREY from anywhere in Termux by typing:"
echo ""
echo "      \033[1;36mgrey\033[0m"
echo ""
echo "\033[1;35m========================================================\033[0m"
echo ""

read -p "Do you want to launch GREY now? (y/n): " choice
case "$choice" in 
  y|Y ) clear; grey ;;
  * ) echo "Setup finished. Type 'grey' whenever you are ready." ;;
esac