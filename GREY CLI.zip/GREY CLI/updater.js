#!/usr/bin/env node

import { execSync, spawn } from "node:child_process";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import chalk from "chalk";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO_URL = "https://github.com/DrexxIsHere/Grey.git";
const RAW_PKG_URL = "https://raw.githubusercontent.com/DrexxIsHere/Grey/main/package.json";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function compareVersions(vA, vB) {
  const cleanA = vA.replace(/^v/i, "").split("-")[0];
  const cleanB = vB.replace(/^v/i, "").split("-")[0];

  const partsA = cleanA.split(".").map((n) => parseInt(n, 10) || 0);
  const partsB = cleanB.split(".").map((n) => parseInt(n, 10) || 0);

  const len = Math.max(partsA.length, partsB.length);
  for (let i = 0; i < len; i++) {
    const a = partsA[i] || 0;
    const b = partsB[i] || 0;
    if (a > b) return 1;
    if (a < b) return -1;
  }
  return 0;
}

function getLocalVersion() {
  const pkgPath = path.join(__dirname, "package.json");
  if (!fs.existsSync(pkgPath)) return "0.0.0";
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
    return pkg.version || "0.0.0";
  } catch {
    return "0.0.0";
  }
}

function ensureRemoteConfigured() {
  try {
    const remotes = execSync("git remote -v 2>&1", { cwd: __dirname, encoding: "utf-8" });
    if (!remotes.includes("origin")) {
      execSync(`git remote add origin ${REPO_URL}`, { cwd: __dirname, stdio: "ignore" });
    }
  } catch {
    try {
      execSync("git init", { cwd: __dirname, stdio: "ignore" });
      execSync(`git remote add origin ${REPO_URL}`, { cwd: __dirname, stdio: "ignore" });
    } catch {}
  }
}

async function getRemoteVersion() {
  try {
    ensureRemoteConfigured();
    execSync("git fetch --tags origin 2>&1", { cwd: __dirname, stdio: "ignore" });

    const branches = ["origin/main", "origin/master"];
    for (const b of branches) {
      try {
        const rawContent = execSync(`git show ${b}:package.json 2>&1`, {
          cwd: __dirname,
          encoding: "utf-8"
        });
        const parsed = JSON.parse(rawContent);
        if (parsed.version) return parsed.version;
      } catch {}
    }

    const tagOutput = execSync("git tag -l --sort=-v:refname 2>&1", {
      cwd: __dirname,
      encoding: "utf-8"
    });
    const latestTag = tagOutput.trim().split("\n")[0];
    if (latestTag) return latestTag.replace(/^v/i, "");
  } catch {}

  try {
    const res = await fetch(RAW_PKG_URL);
    if (res.ok) {
      const data = await res.json();
      if (data.version) return data.version;
    }
  } catch {}

  return null;
}

async function checkForUpdates() {
  const isGit = fs.existsSync(path.join(__dirname, ".git"));
  if (!isGit) {
    try {
      execSync("git init", { cwd: __dirname, stdio: "ignore" });
      execSync(`git remote add origin ${REPO_URL}`, { cwd: __dirname, stdio: "ignore" });
    } catch {
      return;
    }
  }

  const currentVersion = getLocalVersion();
  const remoteVersion = await getRemoteVersion();

  if (!remoteVersion) return;

  if (compareVersions(remoteVersion, currentVersion) > 0) {
    process.stdout.write("\x1B[?25l");
    console.clear();
    console.log(chalk.bold.hex("#8a2be2")("\n  ========================================================"));
    console.log(chalk.bold.hex("#00ffff")("              NEW GREY CLI UPDATE AVAILABLE              "));
    console.log(chalk.bold.hex("#8a2be2")("  ========================================================\n"));
    console.log(`  Current Version : ${chalk.yellow("v" + currentVersion)}`);
    console.log(`  Target Version  : ${chalk.green("v" + remoteVersion)}\n`);
    console.log(chalk.dim("  Preserving your encrypted vault, sessions, and configs...\n"));

    const barWidth = 32;
    for (let i = 0; i <= barWidth; i++) {
      const filled = "█".repeat(i);
      const empty = "░".repeat(barWidth - i);
      const percent = Math.floor((i / barWidth) * 100);
      process.stdout.write(`\r  Downloading v${remoteVersion}: [${chalk.cyan(filled)}${chalk.dim(empty)}] ${percent}% `);
      await sleep(35);
    }

    try {
      execSync("git pull --rebase origin main", { cwd: __dirname, stdio: "ignore" });
    } catch {
      try {
        execSync("git pull origin master", { cwd: __dirname, stdio: "ignore" });
      } catch {}
    }

    try {
      execSync("npm install --silent", { cwd: __dirname, stdio: "ignore" });
    } catch {}

    console.log(chalk.green(`\n\n  ✔ Successfully upgraded to v${remoteVersion}! Restarting GREY...\n`));
    await sleep(900);
    process.stdout.write("\x1B[?25h");

    spawn(process.argv[0], [path.join(__dirname, "index.js")], {
      stdio: "inherit"
    });
    process.exit(0);
  }
}

checkForUpdates();